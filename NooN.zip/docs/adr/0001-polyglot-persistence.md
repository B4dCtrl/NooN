# ADR-0001: Polyglot Persistence

## Status
Accepted

## Context
NOON workloads include transactional user/scan data, full-text retrieval, and relationship analytics.

## Decision
Use:
- PostgreSQL for transactional records and workflow state
- Elasticsearch for mention indexing and search
- Neo4j for reputation graph and association queries

## Consequences
- Better workload fit and scale paths per storage type
- Increased operational complexity and consistency orchestration
