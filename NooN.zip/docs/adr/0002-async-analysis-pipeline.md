# ADR-0002: Async Analysis Pipeline

## Status
Accepted

## Context
Synchronous scan->analysis creates high latency and tight coupling.

## Decision
Use RabbitMQ queue `analysis_jobs` between scraper and analysis services.
Run dedicated analysis worker consumers.

## Consequences
- Lower scan API latency
- Horizontal scale by increasing worker replicas
- Eventual consistency for analysis and notifications
