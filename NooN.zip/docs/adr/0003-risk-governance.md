# ADR-0003: Risk Governance and Explainability

## Status
Accepted

## Context
Risk outputs may impact legal and reputation actions.

## Decision
Every analysis output must include:
- `classification`
- `risk_score`
- `confidence`
- `legal_risk`

High-risk alerts are emitted only when risk threshold is met.

## Consequences
- Better auditability and reviewer context
- Safer automation boundaries
