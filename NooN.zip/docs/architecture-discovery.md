# NOON Architectural Discovery (Reworked MVP)

## 1. Critical unresolved decisions and why they matter
1. Jurisdiction matrix and legal mode: determines lawful data collection and user rights handling.
2. Source policy (API-first vs scraping): balances coverage against legal/operational risk.
3. Identity resolution confidence thresholds: prevents harmful false associations.
4. Consent and lawful basis model: required for privacy compliance and trust.
5. Data retention and deletion policy: controls legal and breach exposure.
6. Multi-tenant isolation strategy: required for enterprise-grade security.
7. Risk scoring governance: needed for explainable, defensible outcomes.
8. Abuse prevention controls: prevents stalking/doxxing misuse.
9. Human-review thresholds: avoids unsafe fully automated mitigation.
10. API monetization and SLA model: drives architecture and throttling design.

## 2. Selected architecture for this MVP rework
- Polyglot data model (Postgres + Elasticsearch + Neo4j)
- Event-driven analysis pipeline with RabbitMQ
- Gateway-centric public API, internal service-to-service calls
- Explainable analysis outputs with legal tagging and confidence
- Notification trigger from async analysis worker

## 3. Hard technical problems and strategies
- Entity resolution: hybrid deterministic + probabilistic matching with confidence and manual override.
- Anti-bot/source drift: source adapters with health checks, retries, and fallback connectors.
- False positives: model confidence + thresholding + reviewer queue for high-risk classes.
- Throughput: distributed workers, backpressure with queue depth autoscaling.
- Legal variability: policy-as-code with jurisdiction feature flags.

## 4. End-to-end data pipeline
1. Discovery jobs created from user queries/aliases.
2. Scraper workers discover and normalize mentions.
3. Mentions stored in Postgres + indexed in Elasticsearch.
4. Mention IDs published to RabbitMQ `analysis_jobs`.
5. Analysis workers classify risk/sentiment/legal flags and persist results.
6. High-risk analysis emits notifications.
7. Reputation engine aggregates analysis and computes global score.
8. Graph service ingests mention relationships to Neo4j.
9. Report service generates JSON/PDF outputs.

## 5. Security and legal model
- JWT auth for MVP, path to OIDC/SAML for enterprise.
- Strict API rate limits and abuse heuristics.
- Data minimization and explicit retention by table class.
- DSAR-ready delete/export workflow (to be expanded in next phase).
- Audit logging for score and mitigation generation steps.

## 6. MVP boundary
Included:
- Auth, scan, mention index, async analysis, score, graph ingest, cleanup suggestions, reporting, notifications, dashboard.

Postponed:
- Dark web monitoring, leak-breach connectors, browser extension, automated legal filing, advanced compliance workflows.

## 7. Scale evolution
- 100 users: single-region Compose/K8s baseline.
- 10k users: worker autoscaling, managed data stores, stronger observability.
- 1M users: multi-region, sharded queues/storage, policy engine, dedicated trust/safety ops.
