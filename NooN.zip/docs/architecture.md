# NOON Architecture (MVP)

## Services
- `api-gateway`: unified public API and orchestration
- `auth-service`: registration/login and JWT issue
- `user-service`: authenticated user profile
- `scraper-service`: public mention discovery and Elasticsearch indexing
- `analysis-service`: NLP sentiment/risk/legal classification + plugin endpoint
- `analysis-worker`: RabbitMQ consumer for async mention analysis
- `reputation-engine`: score calculation (0-100)
- `cleanup-service`: mitigation and takedown strategy generation
- `report-service`: JSON/PDF report generation
- `reputation-graph-service`: Neo4j graph ingest/query
- `notification-service`: dashboard/email notification records

## Data Stores
- PostgreSQL: `users`, `scans`, `mentions`, `analysis_results`, `cleanup_tasks`, `notifications`
- Neo4j: reputation graph entities and associations
- Elasticsearch: mention search/indexing
- Redis: cache/session placeholder for scale-out
- RabbitMQ: async analysis jobs

## Scale Notes
- Stateless service containers, horizontal scaling ready
- Per-service Dockerfiles for independent deploy
- Queue-based scan-to-analysis ingestion path with dedicated worker
- API gateway keeps external contract stable while services evolve
- K8s manifests included for core entry services
