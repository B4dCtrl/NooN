# NOON - Digital Reputation Intelligence Platform (Reworked MVP)

NOON is a modular microservice platform for digital footprint discovery, AI risk analysis, reputation scoring, graph intelligence, and mitigation workflows.

## Architecture

- Gateway: `api-gateway`
- Services: `auth`, `user`, `scraper`, `analysis`, `reputation-engine`, `cleanup`, `report`, `reputation-graph`, `notification`
- Data: PostgreSQL + Elasticsearch + Neo4j
- Async backbone: RabbitMQ (`analysis_jobs`)
- Cache: Redis
- Frontend: Next.js 14 + TypeScript + Tailwind

## Reworked Pipeline

1. `POST /scan/start` stores mentions and publishes jobs to RabbitMQ.
2. `analysis-worker` consumes mention jobs asynchronously.
3. Analysis persists:
   - `sentiment_score`
   - `risk_score`
   - `classification`
   - `confidence`
   - `legal_risk`
4. High-risk findings trigger dashboard notifications.
5. Reputation engine computes global score and classification.
6. Report service emits JSON/PDF reports.

## Project Structure

```text
NooN/
  backend/services/*
  frontend/
  infra/postgres/init.sql
  infra/k8s/
  docs/
    architecture.md
    architecture-discovery.md
    api-examples.http
    adr/
```

## Run

```bash
docker compose up --build
```

- Frontend: `http://localhost:3000`
- API Gateway: `http://localhost:8000`
- RabbitMQ UI: `http://localhost:15672`
- Neo4j Browser: `http://localhost:7474`
- Elasticsearch: `http://localhost:9200`

## Architecture Decisions

See:
- `docs/adr/0001-polyglot-persistence.md`
- `docs/adr/0002-async-analysis-pipeline.md`
- `docs/adr/0003-risk-governance.md`

## Request Examples

See `docs/api-examples.http`.
