const KEYS = {
  user: "noon_user",
  tasks: "noon_tasks",
};

const authCard = document.getElementById("auth-card");
const dashboard = document.getElementById("dashboard");
const authForm = document.getElementById("auth-form");
const usernameInput = document.getElementById("username");
const welcome = document.getElementById("welcome");
const logoutBtn = document.getElementById("logout");
const taskForm = document.getElementById("task-form");
const taskTitle = document.getElementById("task-title");
const taskPriority = document.getElementById("task-priority");
const filter = document.getElementById("filter");
const taskList = document.getElementById("task-list");
const emptyState = document.getElementById("empty-state");

function getUser() {
  return localStorage.getItem(KEYS.user);
}

function setUser(name) {
  localStorage.setItem(KEYS.user, name);
}

function clearUser() {
  localStorage.removeItem(KEYS.user);
}

function getTasks() {
  const raw = localStorage.getItem(KEYS.tasks);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveTasks(tasks) {
  localStorage.setItem(KEYS.tasks, JSON.stringify(tasks));
}

function login(name) {
  setUser(name);
  welcome.textContent = `Olá, ${name}`;
  authCard.classList.add("hidden");
  dashboard.classList.remove("hidden");
  renderTasks();
}

function logout() {
  clearUser();
  dashboard.classList.add("hidden");
  authCard.classList.remove("hidden");
}

function createTask(title, priority) {
  const tasks = getTasks();
  const task = {
    id: crypto.randomUUID(),
    title,
    priority,
    done: false,
    createdAt: new Date().toISOString(),
  };
  tasks.unshift(task);
  saveTasks(tasks);
}

function updateTask(id, updater) {
  const tasks = getTasks().map((task) => (task.id === id ? updater(task) : task));
  saveTasks(tasks);
}

function removeTask(id) {
  const tasks = getTasks().filter((task) => task.id !== id);
  saveTasks(tasks);
}

function getFilteredTasks() {
  const tasks = getTasks();
  if (filter.value === "pendente") return tasks.filter((t) => !t.done);
  if (filter.value === "concluida") return tasks.filter((t) => t.done);
  return tasks;
}

function renderTasks() {
  const tasks = getFilteredTasks();
  taskList.innerHTML = "";

  if (!tasks.length) {
    emptyState.classList.remove("hidden");
    return;
  }

  emptyState.classList.add("hidden");
  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.className = `task-item ${task.done ? "done" : ""}`;
    li.innerHTML = `
      <div>
        <strong>${task.title}</strong><br />
        <small>${new Date(task.createdAt).toLocaleString("pt-BR")}</small>
      </div>
      <span class="pill ${task.priority}">${task.priority}</span>
      <div class="actions">
        <button data-action="toggle" data-id="${task.id}">
          ${task.done ? "Reabrir" : "Concluir"}
        </button>
        <button data-action="delete" class="danger" data-id="${task.id}">
          Excluir
        </button>
      </div>
    `;
    taskList.appendChild(li);
  });
}

authForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = usernameInput.value.trim();
  if (!name) return;
  login(name);
  authForm.reset();
});

logoutBtn.addEventListener("click", logout);

taskForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = taskTitle.value.trim();
  if (!title) return;
  createTask(title, taskPriority.value);
  taskForm.reset();
  renderTasks();
});

filter.addEventListener("change", renderTasks);

taskList.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLButtonElement)) return;
  const id = target.dataset.id;
  const action = target.dataset.action;
  if (!id || !action) return;

  if (action === "toggle") {
    updateTask(id, (task) => ({ ...task, done: !task.done }));
  }

  if (action === "delete") {
    removeTask(id);
  }

  renderTasks();
});

const currentUser = getUser();
if (currentUser) {
  login(currentUser);
}
