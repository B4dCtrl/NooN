CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scans (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  scan_date TIMESTAMP NOT NULL DEFAULT NOW(),
  status VARCHAR(50) NOT NULL,
  reputation_score INTEGER NOT NULL DEFAULT 50
);

CREATE TABLE IF NOT EXISTS mentions (
  id SERIAL PRIMARY KEY,
  scan_id INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
  source VARCHAR(100) NOT NULL,
  url VARCHAR(800) NOT NULL,
  content TEXT NOT NULL,
  author VARCHAR(255),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS analysis_results (
  id SERIAL PRIMARY KEY,
  mention_id INTEGER UNIQUE NOT NULL REFERENCES mentions(id) ON DELETE CASCADE,
  sentiment_score FLOAT NOT NULL,
  risk_score FLOAT NOT NULL,
  classification VARCHAR(100) NOT NULL,
  confidence FLOAT NOT NULL DEFAULT 0.7,
  legal_risk VARCHAR(100) NOT NULL DEFAULT 'none',
  summary TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cleanup_tasks (
  id SERIAL PRIMARY KEY,
  mention_id INTEGER NOT NULL REFERENCES mentions(id) ON DELETE CASCADE,
  action_type VARCHAR(120) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'open',
  details TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  channel VARCHAR(50) NOT NULL DEFAULT 'dashboard',
  message TEXT NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'unread',
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scans_user_id ON scans(user_id);
CREATE INDEX IF NOT EXISTS idx_mentions_scan_id ON mentions(scan_id);
CREATE INDEX IF NOT EXISTS idx_analysis_mention_id ON analysis_results(mention_id);
CREATE INDEX IF NOT EXISTS idx_cleanup_mention_id ON cleanup_tasks(mention_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
