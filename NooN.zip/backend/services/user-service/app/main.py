from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db
from .models import User
from .schemas import UserResponse
from .security import require_user

app = FastAPI(title="NOON User Service", version="0.1.0")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "user-service"}


@app.get("/users/me", response_model=UserResponse)
async def me(email: str = Depends(require_user), db: AsyncSession = Depends(get_db)) -> UserResponse:
    user = await db.scalar(select(User).where(User.email == email))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return UserResponse(id=user.id, email=user.email, created_at=user.created_at)
