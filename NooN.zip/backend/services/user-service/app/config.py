from pydantic import BaseModel


class Settings(BaseModel):
    postgres_url: str = "postgresql+asyncpg://noon:noon@postgres:5432/noon"
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"


settings = Settings()
