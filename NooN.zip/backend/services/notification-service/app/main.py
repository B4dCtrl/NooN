from fastapi import FastAPI, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db, engine
from .models import Base, Notification
from .schemas import NotificationIn, NotificationOut

app = FastAPI(title="NOON Notification Service", version="0.1.0")


@app.on_event("startup")
async def startup() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "notification-service"}


@app.post("/notifications", response_model=NotificationOut)
async def create_notification(payload: NotificationIn, db: AsyncSession = Depends(get_db)) -> NotificationOut:
    item = Notification(user_id=payload.user_id, message=payload.message, channel=payload.channel, status="unread")
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return NotificationOut(id=item.id, user_id=item.user_id, channel=item.channel, message=item.message, status=item.status)


@app.get("/notifications/{user_id}", response_model=list[NotificationOut])
async def list_notifications(user_id: int, db: AsyncSession = Depends(get_db)) -> list[NotificationOut]:
    rows = (await db.scalars(select(Notification).where(Notification.user_id == user_id).order_by(Notification.id.desc()))).all()
    return [NotificationOut(id=n.id, user_id=n.user_id, channel=n.channel, message=n.message, status=n.status) for n in rows]
