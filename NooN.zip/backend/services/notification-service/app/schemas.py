from pydantic import BaseModel


class NotificationIn(BaseModel):
    user_id: int
    message: str
    channel: str = "dashboard"


class NotificationOut(BaseModel):
    id: int
    user_id: int
    channel: str
    message: str
    status: str
