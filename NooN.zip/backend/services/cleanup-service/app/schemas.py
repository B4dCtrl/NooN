from pydantic import BaseModel


class CleanupRequest(BaseModel):
    mention_id: int


class CleanupTaskOut(BaseModel):
    id: int
    mention_id: int
    action_type: str
    status: str
    details: str
