from .models import AnalysisResult


def mitigation_actions(analysis: AnalysisResult) -> list[tuple[str, str]]:
    actions = []
    if analysis.risk_score >= 70:
        actions.append(("content removal request", "Draft legal and policy-based removal request."))
        actions.append(("search deindex request", "Submit deindex request for sensitive content."))
    if analysis.classification in {"offensive", "harassment"}:
        actions.append(("platform report template", "Prepare abuse report template for platform moderation."))
    actions.append(("reputation mitigation suggestion", "Publish corrective factual content and monitor recrawl."))
    return actions
