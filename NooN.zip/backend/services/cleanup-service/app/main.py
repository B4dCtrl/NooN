from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db, engine
from .models import Base, Mention, AnalysisResult, CleanupTask
from .schemas import CleanupRequest, CleanupTaskOut
from .strategy import mitigation_actions

app = FastAPI(title="NOON Cleanup Service", version="0.1.0")


@app.on_event("startup")
async def startup() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "cleanup-service"}


@app.post("/cleanup/request", response_model=list[CleanupTaskOut])
async def create_cleanup_tasks(payload: CleanupRequest, db: AsyncSession = Depends(get_db)) -> list[CleanupTaskOut]:
    mention = await db.get(Mention, payload.mention_id)
    if not mention:
        raise HTTPException(status_code=404, detail="Mention not found")

    analysis = await db.scalar(select(AnalysisResult).where(AnalysisResult.mention_id == payload.mention_id))
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found for mention")

    tasks = []
    for action_type, details in mitigation_actions(analysis):
        task = CleanupTask(mention_id=payload.mention_id, action_type=action_type, details=details, status="open")
        db.add(task)
        tasks.append(task)

    await db.commit()
    for task in tasks:
        await db.refresh(task)

    return [
        CleanupTaskOut(
            id=t.id,
            mention_id=t.mention_id,
            action_type=t.action_type,
            status=t.status,
            details=t.details,
        )
        for t in tasks
    ]
