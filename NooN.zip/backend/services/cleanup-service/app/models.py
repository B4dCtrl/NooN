from datetime import datetime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import DateTime, String, Text, Integer, Float, ForeignKey


class Base(DeclarativeBase):
    pass


class AnalysisResult(Base):
    __tablename__ = "analysis_results"

    id: Mapped[int] = mapped_column(primary_key=True)
    mention_id: Mapped[int] = mapped_column(Integer, unique=True)
    sentiment_score: Mapped[float] = mapped_column(Float)
    risk_score: Mapped[float] = mapped_column(Float)
    classification: Mapped[str] = mapped_column(String(100))


class Mention(Base):
    __tablename__ = "mentions"

    id: Mapped[int] = mapped_column(primary_key=True)
    scan_id: Mapped[int] = mapped_column(Integer)
    source: Mapped[str] = mapped_column(String(100))
    url: Mapped[str] = mapped_column(String(800))
    content: Mapped[str] = mapped_column(Text)


class CleanupTask(Base):
    __tablename__ = "cleanup_tasks"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    mention_id: Mapped[int] = mapped_column(ForeignKey("mentions.id"), index=True)
    action_type: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(50), default="open")
    details: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
