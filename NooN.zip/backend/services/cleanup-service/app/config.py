from pydantic import BaseModel


class Settings(BaseModel):
    postgres_url: str = "postgresql+asyncpg://noon:noon@postgres:5432/noon"


settings = Settings()
