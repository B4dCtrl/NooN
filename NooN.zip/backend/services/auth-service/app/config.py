from pydantic import BaseModel


class Settings(BaseModel):
    service_name: str = "auth-service"
    postgres_url: str = "postgresql+asyncpg://noon:noon@postgres:5432/noon"
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_exp_minutes: int = 60


settings = Settings()
