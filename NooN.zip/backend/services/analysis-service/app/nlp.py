from typing import Literal

RISK_LABELS: list[str] = [
    "neutral",
    "positive",
    "offensive",
    "harassment",
    "political sensitivity",
    "illegal activity",
    "personal data exposure",
]


def rule_based_analysis(text: str) -> tuple[float, float, str]:
    lower = text.lower()
    sentiment = 0.55
    risk = 20.0
    cls: Literal[
        "neutral", "positive", "offensive", "harassment", "political sensitivity", "illegal activity", "personal data exposure"
    ] = "neutral"

    if any(x in lower for x in ["great", "excellent", "positive"]):
        sentiment, risk, cls = 0.88, 8.0, "positive"
    if any(x in lower for x in ["idiot", "hate", "offensive"]):
        sentiment, risk, cls = 0.15, 80.0, "offensive"
    if any(x in lower for x in ["dox", "address", "phone number", "cpf"]):
        sentiment, risk, cls = 0.1, 90.0, "personal data exposure"
    if any(x in lower for x in ["fraud", "crime", "illegal"]):
        sentiment, risk, cls = 0.12, 92.0, "illegal activity"
    if any(x in lower for x in ["election", "party", "politics"]):
        sentiment, risk, cls = 0.4, 58.0, "political sensitivity"

    return sentiment, risk, cls


def suggest_rewrite(text: str) -> str:
    return (
        "Use factual language, remove personal identifiers, and replace accusatory tone "
        "with neutral context plus verified references."
    )


def legal_implication(text: str) -> str:
    lower = text.lower()
    if any(x in lower for x in ["cpf", "address", "phone number", "dox", "leak"]):
        return "privacy exposure"
    if any(x in lower for x in ["fraud", "crime", "illegal", "scam"]):
        return "defamation or criminal allegation"
    if any(x in lower for x in ["harassment", "threat", "hate"]):
        return "harassment"
    return "none"


def confidence_score(text: str, classification: str) -> float:
    base = 0.65
    length_boost = min(len(text) / 800.0, 0.2)
    class_boost = 0.12 if classification in {"illegal activity", "personal data exposure"} else 0.06
    return round(min(0.97, base + length_boost + class_boost), 2)
