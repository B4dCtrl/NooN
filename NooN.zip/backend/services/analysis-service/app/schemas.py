from pydantic import BaseModel


class AnalyzeMentionRequest(BaseModel):
    mention_id: int


class AnalyzeContentRequest(BaseModel):
    text: str


class AnalysisResponse(BaseModel):
    sentiment_score: float
    risk_score: float
    classification: str
    confidence: float
    legal_risk: str
    suggested_rewrite: str | None = None
