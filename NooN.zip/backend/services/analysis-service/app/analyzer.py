import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .config import settings
from .models import Mention, AnalysisResult, Scan
from .nlp import rule_based_analysis, suggest_rewrite, confidence_score, legal_implication


async def analyze_and_persist(db: AsyncSession, mention_id: int) -> AnalysisResult:
    mention = await db.get(Mention, mention_id)
    if not mention:
        raise ValueError("Mention not found")

    sentiment, risk, classification = rule_based_analysis(mention.content)
    confidence = confidence_score(mention.content, classification)
    legal_risk = legal_implication(mention.content)

    existing = await db.scalar(select(AnalysisResult).where(AnalysisResult.mention_id == mention_id))
    if existing:
        existing.sentiment_score = sentiment
        existing.risk_score = risk
        existing.classification = classification
        existing.confidence = confidence
        existing.legal_risk = legal_risk
        existing.summary = suggest_rewrite(mention.content)
        record = existing
    else:
        record = AnalysisResult(
            mention_id=mention_id,
            sentiment_score=sentiment,
            risk_score=risk,
            classification=classification,
            confidence=confidence,
            legal_risk=legal_risk,
            summary=suggest_rewrite(mention.content),
        )
        db.add(record)

    await db.commit()
    await db.refresh(record)

    if risk >= 70:
        scan = await db.get(Scan, mention.scan_id)
        if scan:
            async with httpx.AsyncClient(timeout=6.0) as client:
                await client.post(
                    f"{settings.notification_service_url}/notifications",
                    json={
                        "user_id": scan.user_id,
                        "channel": "dashboard",
                        "message": f"High-risk mention detected ({classification}) | legal: {legal_risk}",
                    },
                )

    return record
