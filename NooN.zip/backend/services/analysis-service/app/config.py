import os
from pydantic import BaseModel


class Settings(BaseModel):
    postgres_url: str = "postgresql+asyncpg://noon:noon@postgres:5432/noon"
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    rabbitmq_url: str = "amqp://guest:guest@rabbitmq/"
    notification_service_url: str = "http://notification-service:8000"


settings = Settings()
