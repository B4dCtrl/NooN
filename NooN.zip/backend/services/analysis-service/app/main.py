from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db, engine
from .models import Base
from .schemas import AnalyzeMentionRequest, AnalyzeContentRequest, AnalysisResponse
from .nlp import rule_based_analysis, suggest_rewrite, confidence_score, legal_implication
from .analyzer import analyze_and_persist

app = FastAPI(title="NOON Analysis Service", version="0.1.0")


@app.on_event("startup")
async def startup() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "analysis-service"}


@app.post("/analysis/mention", response_model=AnalysisResponse)
async def analyze_mention(payload: AnalyzeMentionRequest, db: AsyncSession = Depends(get_db)) -> AnalysisResponse:
    try:
        result = await analyze_and_persist(db, payload.mention_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Mention not found")

    return AnalysisResponse(
        sentiment_score=result.sentiment_score,
        risk_score=result.risk_score,
        classification=result.classification,
        confidence=result.confidence,
        legal_risk=result.legal_risk,
    )


@app.post("/analyze-content", response_model=AnalysisResponse)
async def analyze_content(payload: AnalyzeContentRequest) -> AnalysisResponse:
    sentiment, risk, classification = rule_based_analysis(payload.text)
    confidence = confidence_score(payload.text, classification)
    legal_risk = legal_implication(payload.text)
    return AnalysisResponse(
        sentiment_score=sentiment,
        risk_score=risk,
        classification=classification,
        confidence=confidence,
        legal_risk=legal_risk,
        suggested_rewrite=suggest_rewrite(payload.text),
    )
