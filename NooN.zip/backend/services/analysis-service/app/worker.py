import asyncio
import aio_pika
from sqlalchemy.ext.asyncio import AsyncSession

from .config import settings
from .database import AsyncSessionLocal
from .analyzer import analyze_and_persist


async def process_message(message: aio_pika.IncomingMessage) -> None:
    async with message.process(requeue=False):
        mention_id = int(message.body.decode())
        async with AsyncSessionLocal() as session:  # type: AsyncSession
            await analyze_and_persist(session, mention_id)


async def run_worker() -> None:
    connection = await aio_pika.connect_robust(settings.rabbitmq_url)
    async with connection:
        channel = await connection.channel()
        queue = await channel.declare_queue("analysis_jobs", durable=True)
        await queue.consume(process_message)
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(run_worker())
