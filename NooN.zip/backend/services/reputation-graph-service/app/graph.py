from neo4j import GraphDatabase
from .config import settings


def get_driver():
    return GraphDatabase.driver(settings.neo4j_uri, auth=(settings.neo4j_user, settings.neo4j_password))


def upsert_user_mention_graph(user_id: int, mention: dict) -> None:
    driver = get_driver()
    with driver.session() as session:
        session.run(
            """
            MERGE (u:User {id: $user_id})
            MERGE (c:Content {url: $url})
            SET c.source = $source, c.snippet = $content
            MERGE (u)-[:USER_MENTIONED_IN]->(c)
            """,
            user_id=user_id,
            url=mention["url"],
            source=mention["source"],
            content=mention["content"],
        )
    driver.close()


def related_topics(user_id: int) -> list[dict]:
    driver = get_driver()
    with driver.session() as session:
        records = session.run(
            """
            MATCH (u:User {id: $user_id})-[:USER_MENTIONED_IN]->(c:Content)
            RETURN c.source as source, count(c) as mentions
            ORDER BY mentions DESC
            """,
            user_id=user_id,
        )
        result = [record.data() for record in records]
    driver.close()
    return result
