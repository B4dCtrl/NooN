from pydantic import BaseModel


class Settings(BaseModel):
    neo4j_uri: str = "bolt://neo4j:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "noon12345"


settings = Settings()
