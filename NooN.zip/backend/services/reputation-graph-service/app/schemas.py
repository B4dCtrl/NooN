from pydantic import BaseModel


class GraphIngestRequest(BaseModel):
    user_id: int
    mentions: list[dict]
