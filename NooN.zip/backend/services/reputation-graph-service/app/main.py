from fastapi import FastAPI
from .schemas import GraphIngestRequest
from .graph import upsert_user_mention_graph, related_topics

app = FastAPI(title="NOON Reputation Graph Service", version="0.1.0")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "reputation-graph-service"}


@app.post("/graph/ingest")
async def ingest(payload: GraphIngestRequest) -> dict:
    for mention in payload.mentions:
        upsert_user_mention_graph(payload.user_id, mention)
    return {"status": "ingested", "count": len(payload.mentions)}


@app.get("/graph/{user_id}")
async def graph_query(user_id: int) -> dict:
    return {"user_id": user_id, "clusters": related_topics(user_id)}
