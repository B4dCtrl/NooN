from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db
from .models import Scan, Mention, AnalysisResult
from .engine import compute_reputation

app = FastAPI(title="NOON Reputation Engine", version="0.1.0")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "reputation-engine"}


@app.get("/reputation-score/{user_id}")
async def reputation_score(user_id: int, db: AsyncSession = Depends(get_db)) -> dict:
    scans = (await db.scalars(select(Scan).where(Scan.user_id == user_id))).all()
    if not scans:
        raise HTTPException(status_code=404, detail="No scans found for user")

    scan_ids = [s.id for s in scans]
    mentions = (await db.scalars(select(Mention).where(Mention.scan_id.in_(scan_ids)))).all()
    if not mentions:
        return {"user_id": user_id, "score": 50.0, "classification": "neutral", "risk_distribution": {}}

    mention_ids = [m.id for m in mentions]
    analyses = (await db.scalars(select(AnalysisResult).where(AnalysisResult.mention_id.in_(mention_ids)))).all()

    by_mention = {a.mention_id: a for a in analyses}
    sentiments, risks, sources, timestamps = [], [], [], []

    for mention in mentions:
        analysis = by_mention.get(mention.id)
        if not analysis:
            continue
        sentiments.append(analysis.sentiment_score)
        risks.append(analysis.risk_score)
        sources.append(mention.source)
        timestamps.append(mention.created_at)

    result = compute_reputation(sentiments, risks, sources, timestamps)

    latest = sorted(scans, key=lambda s: s.scan_date, reverse=True)[0]
    latest.reputation_score = int(result["score"])
    await db.commit()

    return {
        "user_id": user_id,
        "score": result["score"],
        "classification": result["label"],
        "risk_distribution": result["risk_distribution"],
    }
