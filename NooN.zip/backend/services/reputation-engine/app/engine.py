from datetime import datetime, timezone
from collections import Counter

SOURCE_CREDIBILITY = {
    "news": 0.9,
    "blog": 0.7,
    "forum": 0.5,
    "social": 0.6,
}


def classify(score: float) -> str:
    if score < 20:
        return "critical risk"
    if score < 40:
        return "high risk"
    if score < 70:
        return "neutral"
    if score < 90:
        return "positive"
    return "excellent"


def compute_reputation(
    sentiments: list[float], risks: list[float], sources: list[str], timestamps: list[datetime]
) -> dict:
    if not sentiments:
        return {"score": 50.0, "label": "neutral", "risk_distribution": {}}

    now = datetime.now(timezone.utc)
    avg_sentiment = sum(sentiments) / len(sentiments)
    avg_risk = sum(risks) / len(risks)
    frequency_penalty = min(20.0, len(sentiments) * 1.2)

    recency_factor = 0.0
    for ts in timestamps:
        age_days = max(0.0, (now - ts.replace(tzinfo=timezone.utc)).total_seconds() / 86400)
        recency_factor += max(0.0, 1.0 - min(age_days / 60.0, 1.0))
    recency_factor = recency_factor / len(timestamps)

    credibility = sum(SOURCE_CREDIBILITY.get(src, 0.5) for src in sources) / len(sources)

    score = 100.0
    score -= (1.0 - avg_sentiment) * 35.0
    score -= (avg_risk / 100.0) * 40.0
    score -= frequency_penalty * (0.3 + (1 - credibility) * 0.4)
    score += recency_factor * 8.0
    score = max(0.0, min(100.0, score))

    risk_distribution = dict(Counter(int(r // 20) * 20 for r in risks))
    return {
        "score": round(score, 2),
        "label": classify(score),
        "risk_distribution": risk_distribution,
    }
