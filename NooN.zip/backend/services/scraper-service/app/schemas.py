from datetime import datetime
from pydantic import BaseModel, HttpUrl


class StartScanRequest(BaseModel):
    user_id: int
    query: str


class MentionOut(BaseModel):
    id: int
    source: str
    url: HttpUrl
    content: str
    author: str | None = None
    created_at: datetime


class ScanResponse(BaseModel):
    scan_id: int
    status: str
    mentions: list[MentionOut]
