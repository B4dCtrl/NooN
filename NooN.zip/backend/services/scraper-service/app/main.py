import asyncio
import random
import aio_pika
import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import FastAPI, Depends

from .config import settings
from .database import get_db, engine
from .models import Base, Scan, Mention
from .schemas import StartScanRequest, MentionOut, ScanResponse

app = FastAPI(title="NOON Scraper Service", version="0.1.0")


@app.on_event("startup")
async def startup() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "scraper-service"}


def mock_discovery(query: str) -> list[dict[str, str]]:
    return [
        {
            "source": "news",
            "url": f"https://example.com/news/{query.replace(' ', '-')}",
            "content": f"Article mentioning {query} with mixed context.",
            "author": "Editorial Desk",
        },
        {
            "source": "forum",
            "url": f"https://forum.example.com/thread/{query.replace(' ', '-')}",
            "content": f"Public discussion about {query} and online behavior.",
            "author": "anonymous_user_21",
        },
    ]


async def publish_analysis_jobs(mention_ids: list[int]) -> None:
    connection = await aio_pika.connect_robust(settings.rabbitmq_url)
    async with connection:
        channel = await connection.channel()
        queue = await channel.declare_queue("analysis_jobs", durable=True)
        for mention_id in mention_ids:
            await channel.default_exchange.publish(
                aio_pika.Message(body=str(mention_id).encode()),
                routing_key=queue.name,
            )


async def index_mentions(scan_id: int, mentions: list[Mention]) -> None:
    async with httpx.AsyncClient(timeout=5.0) as client:
        for mention in mentions:
            payload = {
                "scan_id": scan_id,
                "mention_id": mention.id,
                "source": mention.source,
                "url": mention.url,
                "content": mention.content,
                "created_at": mention.created_at.isoformat(),
            }
            await client.post(f"{settings.elastic_url}/mentions/_doc", json=payload)


@app.post("/scan/start", response_model=ScanResponse)
async def start_scan(payload: StartScanRequest, db: AsyncSession = Depends(get_db)) -> ScanResponse:
    scan = Scan(user_id=payload.user_id, status="running", reputation_score=50)
    db.add(scan)
    await db.flush()

    discovered = mock_discovery(payload.query)
    mentions: list[Mention] = []
    for item in discovered:
        mention = Mention(
            scan_id=scan.id,
            source=item["source"],
            url=item["url"],
            content=item["content"],
            author=item.get("author"),
        )
        mentions.append(mention)
        db.add(mention)

    scan.status = "completed"
    scan.reputation_score = max(0, 100 - random.randint(10, 45))
    await db.commit()

    for mention in mentions:
        await db.refresh(mention)

    await asyncio.gather(
        index_mentions(scan.id, mentions),
        publish_analysis_jobs([m.id for m in mentions]),
    )

    return ScanResponse(
        scan_id=scan.id,
        status=scan.status,
        mentions=[
            MentionOut(
                id=m.id,
                source=m.source,
                url=m.url,
                content=m.content,
                author=m.author,
                created_at=m.created_at,
            )
            for m in mentions
        ],
    )


@app.get("/scan/results/{user_id}")
async def scan_results(user_id: int, db: AsyncSession = Depends(get_db)) -> dict:
    scans = (await db.scalars(select(Scan).where(Scan.user_id == user_id).order_by(Scan.id.desc()))).all()
    return {
        "user_id": user_id,
        "scans": [
            {
                "id": s.id,
                "scan_date": s.scan_date.isoformat(),
                "status": s.status,
                "reputation_score": s.reputation_score,
            }
            for s in scans
        ],
    }


@app.get("/mentions/{user_id}")
async def mentions_by_user(user_id: int, db: AsyncSession = Depends(get_db)) -> dict:
    scans = (await db.scalars(select(Scan).where(Scan.user_id == user_id))).all()
    if not scans:
        return {"user_id": user_id, "mentions": []}

    scan_ids = [s.id for s in scans]
    mentions = (await db.scalars(select(Mention).where(Mention.scan_id.in_(scan_ids)).order_by(Mention.created_at.desc()))).all()
    return {
        "user_id": user_id,
        "mentions": [
            {
                "id": m.id,
                "source": m.source,
                "url": m.url,
                "content": m.content,
                "author": m.author,
                "created_at": m.created_at.isoformat(),
            }
            for m in mentions
        ],
    }
