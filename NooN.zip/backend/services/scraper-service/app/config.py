from pydantic import BaseModel


class Settings(BaseModel):
    postgres_url: str = "postgresql+asyncpg://noon:noon@postgres:5432/noon"
    elastic_url: str = "http://elasticsearch:9200"
    rabbitmq_url: str = "amqp://guest:guest@rabbitmq/"


settings = Settings()
