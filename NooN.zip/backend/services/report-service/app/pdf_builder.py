from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def build_pdf(report: dict) -> bytes:
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    y = 800

    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, y, "NOON Reputation Report")
    y -= 30

    c.setFont("Helvetica", 11)
    for line in [
        f"User ID: {report['user_id']}",
        f"Reputation Score: {report['score']}",
        f"Risk Highlights: {report['high_risk_mentions']}",
        f"Cleanup Recommendations: {len(report['cleanup_recommendations'])}",
    ]:
        c.drawString(50, y, line)
        y -= 20

    c.drawString(50, y, "Timeline:")
    y -= 20
    for item in report["timeline"][:12]:
        c.drawString(55, y, f"- {item}")
        y -= 16
        if y < 80:
            c.showPage()
            y = 800

    c.save()
    return buffer.getvalue()
