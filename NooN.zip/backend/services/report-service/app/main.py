from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from io import BytesIO

from .database import get_db
from .models import Scan, Mention, AnalysisResult, CleanupTask
from .pdf_builder import build_pdf

app = FastAPI(title="NOON Report Service", version="0.1.0")


def summarize(scans: list[Scan], mentions: list[Mention], analyses: dict[int, AnalysisResult], tasks: list[CleanupTask]) -> dict:
    score = scans[-1].reputation_score if scans else 50
    high_risk = sum(1 for m in mentions if analyses.get(m.id) and analyses[m.id].risk_score >= 70)
    timeline = [f"{m.created_at.date()} - {m.source} - {m.url}" for m in sorted(mentions, key=lambda x: x.created_at)]
    return {
        "score": score,
        "high_risk_mentions": high_risk,
        "timeline": timeline,
        "cleanup_recommendations": [t.action_type for t in tasks],
    }


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "report-service"}


@app.get("/reports/{user_id}")
async def get_report(user_id: int, format: str = "json", db: AsyncSession = Depends(get_db)):
    scans = (await db.scalars(select(Scan).where(Scan.user_id == user_id).order_by(Scan.scan_date))).all()
    if not scans:
        raise HTTPException(status_code=404, detail="No scan data found")

    scan_ids = [s.id for s in scans]
    mentions = (await db.scalars(select(Mention).where(Mention.scan_id.in_(scan_ids)))).all()
    mention_ids = [m.id for m in mentions]
    analysis = (await db.scalars(select(AnalysisResult).where(AnalysisResult.mention_id.in_(mention_ids)))).all()
    by_mention = {a.mention_id: a for a in analysis}
    tasks = (await db.scalars(select(CleanupTask).where(CleanupTask.mention_id.in_(mention_ids)))).all()

    report = {"user_id": user_id, **summarize(scans, mentions, by_mention, tasks)}

    if format == "pdf":
        pdf = build_pdf(report)
        return StreamingResponse(
            BytesIO(pdf),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=noon-report-{user_id}.pdf"},
        )

    return JSONResponse(report)
