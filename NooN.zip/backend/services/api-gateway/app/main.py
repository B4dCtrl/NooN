import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from .config import settings

app = FastAPI(title="NOON API Gateway", version="0.1.0")


async def proxy_post(url: str, payload: dict) -> dict:
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.post(url, json=payload)
        if response.status_code >= 400:
            raise HTTPException(status_code=response.status_code, detail=response.text)
        return response.json()


async def proxy_get(url: str) -> dict:
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(url)
        if response.status_code >= 400:
            raise HTTPException(status_code=response.status_code, detail=response.text)
        return response.json()


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "api-gateway"}


@app.post("/auth/register")
async def register(payload: dict):
    return await proxy_post(f"{settings.auth_service_url}/auth/register", payload)


@app.post("/auth/login")
async def login(payload: dict):
    return await proxy_post(f"{settings.auth_service_url}/auth/login", payload)


@app.post("/scan/start")
async def start_scan(payload: dict):
    result = await proxy_post(f"{settings.scraper_service_url}/scan/start", payload)
    mentions = result.get("mentions", [])
    await proxy_post(
        f"{settings.graph_service_url}/graph/ingest",
        {"user_id": payload["user_id"], "mentions": mentions},
    )
    return result


@app.get("/scan/results/{user_id}")
async def scan_results(user_id: int):
    return await proxy_get(f"{settings.scraper_service_url}/scan/results/{user_id}")


@app.get("/mentions/{user_id}")
async def mentions(user_id: int):
    return await proxy_get(f"{settings.scraper_service_url}/mentions/{user_id}")


@app.get("/reputation-score/{user_id}")
async def reputation_score(user_id: int):
    return await proxy_get(f"{settings.reputation_service_url}/reputation-score/{user_id}")


@app.post("/cleanup/request")
async def cleanup_request(payload: dict):
    return await proxy_post(f"{settings.cleanup_service_url}/cleanup/request", payload)


@app.post("/analyze-content")
async def analyze_content(payload: dict):
    return await proxy_post(f"{settings.analysis_service_url}/analyze-content", payload)


@app.get("/reports/{user_id}")
async def report(user_id: int, format: str = "json"):
    if format == "pdf":
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.get(f"{settings.report_service_url}/reports/{user_id}?format=pdf")
            if response.status_code >= 400:
                raise HTTPException(status_code=response.status_code, detail=response.text)
            return StreamingResponse(
                iter([response.content]),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename=noon-report-{user_id}.pdf"},
            )

    return await proxy_get(f"{settings.report_service_url}/reports/{user_id}?format={format}")


@app.get("/dashboard/{user_id}")
async def dashboard(user_id: int):
    mentions_data = await proxy_get(f"{settings.scraper_service_url}/mentions/{user_id}")
    score_data = await proxy_get(f"{settings.reputation_service_url}/reputation-score/{user_id}")
    notifications = await proxy_get(f"{settings.notification_service_url}/notifications/{user_id}")
    graph_data = await proxy_get(f"{settings.graph_service_url}/graph/{user_id}")

    return JSONResponse(
        {
            "score": score_data,
            "mentions": mentions_data,
            "graph": graph_data,
            "notifications": notifications,
        }
    )
