from pydantic import BaseModel


class Settings(BaseModel):
    auth_service_url: str = "http://auth-service:8000"
    scraper_service_url: str = "http://scraper-service:8000"
    analysis_service_url: str = "http://analysis-service:8000"
    reputation_service_url: str = "http://reputation-engine:8000"
    cleanup_service_url: str = "http://cleanup-service:8000"
    report_service_url: str = "http://report-service:8000"
    graph_service_url: str = "http://reputation-graph-service:8000"
    notification_service_url: str = "http://notification-service:8000"


settings = Settings()
