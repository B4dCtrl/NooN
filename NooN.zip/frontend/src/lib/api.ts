export interface ScorePayload {
  user_id: number;
  score: number;
  classification: string;
  risk_distribution: Record<string, number>;
}

export interface Mention {
  id: number;
  source: string;
  url: string;
  content: string;
  author?: string;
  created_at: string;
}

export interface Notification {
  id: number;
  message: string;
  channel: string;
  status: string;
}

export interface DashboardPayload {
  score: ScorePayload;
  mentions: { user_id: number; mentions: Mention[] };
  graph: { user_id: number; clusters: { source: string; mentions: number }[] };
  notifications: Notification[];
}

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export async function getDashboard(userId: number): Promise<DashboardPayload | null> {
  const res = await fetch(`${API_URL}/dashboard/${userId}`, { cache: "no-store" });
  if (!res.ok) return null;
  return res.json();
}
