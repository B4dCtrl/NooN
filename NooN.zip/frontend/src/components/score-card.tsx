import { AlertTriangle, ShieldCheck, TrendingDown } from "lucide-react";

interface ScoreCardProps {
  score: number;
  classification: string;
}

export function ScoreCard({ score, classification }: ScoreCardProps) {
  const tone = score < 40 ? "text-red-700" : score < 70 ? "text-amber-700" : "text-green-700";
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Reputation Score</h2>
        <ShieldCheck className="h-5 w-5 text-primary" />
      </div>
      <p className={`text-4xl font-bold ${tone}`}>{score.toFixed(1)}</p>
      <p className="mt-2 text-sm text-slate-600">Classification: {classification}</p>
      <div className="mt-4 grid grid-cols-2 gap-3 text-xs text-slate-500">
        <div className="rounded-md bg-slate-50 p-2">
          <AlertTriangle className="mb-1 h-4 w-4" />
          Higher risk mentions reduce score.
        </div>
        <div className="rounded-md bg-slate-50 p-2">
          <TrendingDown className="mb-1 h-4 w-4" />
          Recency and frequency influence impact.
        </div>
      </div>
    </div>
  );
}
