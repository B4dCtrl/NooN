export function CleanupPanel({ mentionsCount }: { mentionsCount: number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <h2 className="mb-4 text-lg font-semibold">Cleanup Opportunities</h2>
      <ul className="space-y-2 text-sm text-slate-700">
        <li>High-risk mentions detected: {mentionsCount}</li>
        <li>Generate removal requests for risk score above 70.</li>
        <li>Submit deindex requests for sensitive exposure.</li>
        <li>Publish factual counter-content and track re-indexing.</li>
      </ul>
    </div>
  );
}
