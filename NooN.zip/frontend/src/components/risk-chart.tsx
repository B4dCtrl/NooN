"use client";

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

interface RiskChartProps {
  data: Record<string, number>;
}

export function RiskChart({ data }: RiskChartProps) {
  const chartData = Object.entries(data).map(([bucket, value]) => ({ bucket, value }));
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <h2 className="mb-4 text-lg font-semibold">Risk Distribution</h2>
      <div className="h-60">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <XAxis dataKey="bucket" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#1f5d44" radius={6} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
