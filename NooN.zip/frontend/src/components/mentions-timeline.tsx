import type { Mention } from "@/lib/api";

export function MentionsTimeline({ mentions }: { mentions: Mention[] }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <h2 className="mb-4 text-lg font-semibold">Mention Timeline</h2>
      <div className="space-y-3">
        {mentions.slice(0, 8).map((item) => (
          <article key={item.id} className="rounded-lg border border-slate-200 p-3">
            <div className="mb-1 flex items-center justify-between text-xs text-slate-500">
              <span>{item.source}</span>
              <span>{new Date(item.created_at).toLocaleDateString()}</span>
            </div>
            <p className="text-sm text-slate-700">{item.content}</p>
            <a className="mt-2 inline-block text-xs text-primary underline" href={item.url} target="_blank">
              Open source
            </a>
          </article>
        ))}
      </div>
    </div>
  );
}
