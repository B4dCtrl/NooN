import { getDashboard } from "@/lib/api";
import { ScoreCard } from "@/components/score-card";
import { RiskChart } from "@/components/risk-chart";
import { MentionsTimeline } from "@/components/mentions-timeline";
import { CleanupPanel } from "@/components/cleanup-panel";

export default async function HomePage() {
  const userId = 1;
  const dashboard = await getDashboard(userId);

  return (
    <main className="mx-auto min-h-screen max-w-7xl p-6 md:p-10">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">NOON Reputation Dashboard</h1>
        <p className="text-sm text-slate-600">Digital footprint, risk intelligence, and mitigation actions.</p>
      </header>

      {!dashboard ? (
        <section className="rounded-xl border border-red-200 bg-red-50 p-5 text-red-700">
          API gateway unavailable. Set `NEXT_PUBLIC_API_URL` and ensure backend services are running.
        </section>
      ) : (
        <section className="grid gap-5 md:grid-cols-2">
          <ScoreCard score={dashboard.score.score} classification={dashboard.score.classification} />
          <RiskChart data={dashboard.score.risk_distribution} />
          <MentionsTimeline mentions={dashboard.mentions.mentions} />
          <CleanupPanel mentionsCount={dashboard.mentions.mentions.length} />
        </section>
      )}
    </main>
  );
}
