import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/app/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#f4f7f6",
        foreground: "#11231a",
        card: "#ffffff",
        border: "#dae7df",
        primary: "#1f5d44",
      },
    },
  },
  plugins: [],
};

export default config;
